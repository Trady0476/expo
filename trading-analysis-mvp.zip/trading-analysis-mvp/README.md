# Trading Analysis MVP (Expo + Node)

Educational market-analysis dashboard. It does **not** place trades. It never invents prices: if the backend cannot obtain valid market data it returns `DATA DISCONNECTED` / `INSUFFICIENT DATA`.

## Data provider
This MVP uses Twelve Data behind a Node/Express backend. The backend holds the API key; the Expo app never receives it. Twelve Data supports real-time/historical market data and WebSocket streaming. Verify your plan includes the required Indian index/crypto symbols and real-time entitlements before production.

The default symbols are configurable:
- `NIFTY_SYMBOL=NIFTY`
- `NIFTY_EXCHANGE=NSE`
- `SENSEX_SYMBOL=SENSEX`
- `SENSEX_EXCHANGE=BSE`
- `BTC_SYMBOL=BTC/USD`

If your Twelve Data account uses different identifiers, change only `.env`.

## Requirements
- Node.js 22+
- Expo CLI / `npx expo`
- Android phone with Expo Go for development, or EAS for a standalone build
- Twelve Data API key

## 1. Backend
```bash
cd server
npm install
cp .env.example .env
# Put your Twelve Data key in .env
npm run dev
```

Backend listens on `http://YOUR_COMPUTER_LAN_IP:4000`.

## 2. Mobile
```bash
cd mobile
npm install
```

Create `mobile/.env`:
```env
EXPO_PUBLIC_API_BASE_URL=http://YOUR_COMPUTER_LAN_IP:4000
```

Then:
```bash
npx expo start
```
Scan the QR code from Expo Go. Your phone and computer must be on the same network.

## 3. Android production build
Use EAS:
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build -p android
```

Do not put `TWELVE_DATA_API_KEY` in the Expo `.env`. Only the server has it.

## What is included
- NIFTY 50, SENSEX and BTC tabs
- 1m/3m/5m/15m candles
- EMA 9/21, RSI, DMI/ADX, ATR
- support/resistance
- transparent bullish/bearish scoring
- multi-confirmation BUY/SELL/WAIT logic
- dynamically calculated entry/SL/targets
- clearly marked model projections
- risk calculator
- alerts panel
- historical backtest engine
- data-disconnect handling
- backend WebSocket fan-out with REST polling fallback

### Important data limitation
Indices may not expose a meaningful traded volume field from every data vendor. This app never invents index volume. If volume confirmation is required but missing, the trade signal remains `WAIT` and explains why.

### 3-minute candles
The provider may not offer a native 3-minute interval. The server aggregates real 1-minute OHLCV bars into 3-minute bars; it does not fabricate prices.

## Production checklist
1. Confirm the exact vendor symbol and real-time entitlement for each asset.
2. Use HTTPS/WSS.
3. Add authentication and rate limiting to your backend.
4. Store secrets in a server secret manager.
5. Add persistent alert storage and push notifications.
6. Validate vendor licensing/redistribution rights for your app.
7. Run independent historical validation before relying on any signal.
\n## Exact credential placement\nPut only the server-side key here:\n```text\nserver/.env\nTWELVE_DATA_API_KEY=your_real_key\n```\nDo NOT put that key in `mobile/.env`. The mobile app receives only verified market data from your backend.\n