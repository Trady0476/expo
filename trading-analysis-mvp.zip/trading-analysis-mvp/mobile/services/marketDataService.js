const API=(process.env.EXPO_PUBLIC_API_BASE_URL||'http://localhost:4000').replace(/\/$/,'');
export async function getMarket(asset,timeframe=1){const r=await fetch(`${API}/api/market/${asset}?timeframe=${timeframe}`);if(!r.ok)throw new Error('DATA DISCONNECTED');return r.json();}
export function connectMarketStream(onMessage){const ws=new WebSocket(API.replace(/^http/,'ws')+'/ws');ws.onmessage=e=>{try{onMessage(JSON.parse(e.data))}catch{}};return ()=>ws.close();}
