export function project(candles, analysis, horizonMinutes=1) {
  if(!candles.length || !analysis?.indicators?.atr) return [];
  const last=candles.at(-1), atr=analysis.indicators.atr;
  const bias=analysis.nextMove==='UP'?1:analysis.nextMove==='DOWN'?-1:0;
  const strength=Math.min(1,Math.abs(analysis.bullish-analysis.bearish)/50);
  const out=[]; let prev=last.close;
  for(let i=1;i<=5;i++){
    const drift=bias*atr*0.12*strength*(horizonMinutes/Math.max(1,i));
    const noise=atr*0.08*(i%2?1:-1)*(1-strength*0.5);
    const open=prev;
    const close=Math.max(0,open+drift+noise);
    const high=Math.max(open,close)+atr*0.10;
    const low=Math.min(open,close)-atr*0.10;
    const direction=Math.abs(close-open)<atr*0.04?'Neutral':close>open?'Bullish':'Bearish';
    const probability=Math.round(50+strength*25+(direction==='Neutral'?0:10));
    out.push({index:i,open,high,low,close,direction,probability:Math.min(90,probability)});
    prev=close;
  }
  return out;
}
