import { analyze, entryExit } from './analysis.js';
export function runBacktest(candles){
 let trades=0,wins=0,losses=0,grossProfit=0,grossLoss=0,equity=0,peak=0,maxDD=0;
 for(let i=60;i<candles.length-5;i++){
  const window=candles.slice(0,i+1), a=analyze(window);
  if(a.signal==='WAIT') continue;
  const levels=entryExit(window,a); if(!levels) continue;
  trades++;
  const entry=window.at(-1).close;
  const future=candles.slice(i+1,i+6);
  let result=0;
  if(a.signal==='BUY'){
   const hitSL=future.findIndex(c=>c.low<=levels.stop), hitT=future.findIndex(c=>c.high>=levels.target1);
   if(hitT>=0 && (hitSL<0||hitT<=hitSL)) result=levels.target1-entry; else if(hitSL>=0) result=levels.stop-entry; else result=future.at(-1).close-entry;
  } else {
   const hitSL=future.findIndex(c=>c.high>=levels.stop), hitT=future.findIndex(c=>c.low<=levels.target1);
   if(hitT>=0 && (hitSL<0||hitT<=hitSL)) result=entry-levels.target1; else if(hitSL>=0) result=entry-levels.stop; else result=entry-future.at(-1).close;
  }
  equity+=result; peak=Math.max(peak,equity); maxDD=Math.max(maxDD,peak-equity);
  if(result>0){wins++;grossProfit+=result}else{losses++;grossLoss+=Math.abs(result)}
 }
 return {totalTrades:trades,winningTrades:wins,losingTrades:losses,winRate:trades?wins/trades*100:0,averageProfit:wins?grossProfit/wins:0,averageLoss:losses?grossLoss/losses:0,maxDrawdown:maxDD,profitFactor:grossLoss?grossProfit/grossLoss:null,historical:true};
}
