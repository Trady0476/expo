import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import {WebSocketServer} from 'ws';
import {getMarket, fetchCandles, addClient, startProviderStream, refreshAll, aggregate, cfg} from './data.js';
import {analyze, entryExit} from './analysis.js';
import {project} from './prediction.js';
import {runBacktest} from './backtest.js';

const app=express(), port=Number(process.env.PORT||4000);
app.use(cors());app.use(express.json());
app.get('/health',(req,res)=>res.json({ok:true,time:new Date().toISOString()}));

app.get('/api/market/:asset',async(req,res)=>{
 try{
  const asset=req.params.asset.toUpperCase(), tf=Number(req.query.timeframe||1);
  if(![1,3,5,15].includes(tf)) return res.status(400).json({error:'Unsupported timeframe'});
  const data=await getMarket(asset,tf);
  const a=analyze(data.candles), levels=entryExit(data.candles,a);
  res.json({asset,quote:data.quote,candles:data.candles,analysis:a,levels,projection:{'1':project(data.candles,a,1),'3':project(data.candles,a,3),'5':project(data.candles,a,5)},updatedAt:data.updatedAt});
 }catch(e){res.status(503).json({status:'DATA DISCONNECTED',error:e.message});}
});

app.get('/api/backtest/:asset',async(req,res)=>{
 try{
  const asset=req.params.asset.toUpperCase(), tf=Number(req.query.timeframe||5);
  const candles=aggregate(await fetchCandles(asset,'1min',5000),tf);
  res.json(runBacktest(candles));
 }catch(e){res.status(503).json({error:e.message});}
});

const server=app.listen(port,()=>console.log(`API listening on ${port}`));
const wss=new WebSocketServer({server,path:'/ws'});
wss.on('connection',ws=>addClient(ws));
startProviderStream();
const pollMs=Number(process.env.QUOTE_POLL_MS||5000);
setInterval(()=>refreshAll(),pollMs);
