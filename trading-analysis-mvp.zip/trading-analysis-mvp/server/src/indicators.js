export function ema(values, period) {
  if (!values || values.length < period) return null;
  const k = 2 / (period + 1);
  let e = values.slice(0, period).reduce((a,b)=>a+b,0) / period;
  for (let i=period;i<values.length;i++) e = values[i]*k + e*(1-k);
  return e;
}

export function emaSeries(values, period) {
  const out = Array(values.length).fill(null);
  if (values.length < period) return out;
  const k=2/(period+1);
  let e=values.slice(0,period).reduce((a,b)=>a+b,0)/period;
  out[period-1]=e;
  for(let i=period;i<values.length;i++){e=values[i]*k+e*(1-k);out[i]=e;}
  return out;
}

export function rsiSeries(candles, period=14) {
  const out=Array(candles.length).fill(null);
  if(candles.length<=period) return out;
  let gain=0, loss=0;
  for(let i=1;i<=period;i++){const d=candles[i].close-candles[i-1].close;gain+=Math.max(d,0);loss+=Math.max(-d,0);}
  let avgGain=gain/period, avgLoss=loss/period;
  out[period]=avgLoss===0?100:100-(100/(1+avgGain/avgLoss));
  for(let i=period+1;i<candles.length;i++){
    const d=candles[i].close-candles[i-1].close;
    avgGain=(avgGain*(period-1)+Math.max(d,0))/period;
    avgLoss=(avgLoss*(period-1)+Math.max(-d,0))/period;
    out[i]=avgLoss===0?100:100-(100/(1+avgGain/avgLoss));
  }
  return out;
}

export function dmiAdx(candles, period=14) {
  const n=candles.length, out=Array(n).fill(null);
  if(n<period*2+1) return out;
  const tr=[], plus=[], minus=[];
  for(let i=1;i<n;i++){
    const c=candles[i], p=candles[i-1];
    tr.push(Math.max(c.high-c.low,Math.abs(c.high-p.close),Math.abs(c.low-p.close)));
    const up=c.high-p.high, down=p.low-c.low;
    plus.push(up>down&&up>0?up:0);
    minus.push(down>up&&down>0?down:0);
  }
  let atr=tr.slice(0,period).reduce((a,b)=>a+b,0);
  let pDM=plus.slice(0,period).reduce((a,b)=>a+b,0);
  let mDM=minus.slice(0,period).reduce((a,b)=>a+b,0);
  const dx=[];
  for(let i=period;i<tr.length;i++){
    atr=atr-atr/period+tr[i];
    pDM=pDM-pDM/period+plus[i];
    mDM=mDM-mDM/period+minus[i];
    const pdi=atr?100*pDM/atr:0, mdi=atr?100*mDM/atr:0;
    const dxv=(pdi+mdi)?100*Math.abs(pdi-mdi)/(pdi+mdi):0;
    dx.push({index:i+1,pdi,mdi,dx:dxv});
  }
  if(dx.length<period) return out;
  let adx=dx.slice(0,period).reduce((a,b)=>a+b.dx,0)/period;
  for(let j=period;j<dx.length;j++){
    adx=(adx*(period-1)+dx[j].dx)/period;
    const d=dx[j];
    out[d.index]={pdi:d.pdi,mdi:d.mdi,adx};
  }
  return out;
}

export function atr(candles, period=14) {
  if(candles.length<period+1) return null;
  const tr=[];
  for(let i=1;i<candles.length;i++){
    const c=candles[i],p=candles[i-1];
    tr.push(Math.max(c.high-c.low,Math.abs(c.high-p.close),Math.abs(c.low-p.close)));
  }
  return tr.slice(-period).reduce((a,b)=>a+b,0)/Math.min(period,tr.length);
}

export function supportResistance(candles, lookback=20) {
  const a=candles.slice(-lookback);
  if(!a.length) return {support:null,resistance:null};
  return {support:Math.min(...a.map(x=>x.low)),resistance:Math.max(...a.map(x=>x.high))};
}

export function volumeStats(candles, lookback=20) {
  const vs=candles.map(c=>Number(c.volume)||0).slice(-lookback);
  if(!vs.length || vs.every(v=>v<=0)) return {available:false,ratio:null,average:null};
  const average=vs.reduce((a,b)=>a+b,0)/vs.length;
  const current=vs[vs.length-1];
  return {available:true,ratio:average?current/average:null,average};
}

export function indicators(candles) {
  const closes=candles.map(c=>c.close);
  const es9=emaSeries(closes,9), es21=emaSeries(closes,21), rs=rsiSeries(candles), da=dmiAdx(candles);
  const last=candles.length-1;
  return {
    ema9:es9[last], ema21:es21[last], rsi:rs[last],
    dmi:da[last]||null, atr:atr(candles), ema9Series:es9, ema21Series:es21,
    rsiSeries:rs, dmiSeries:da, volume:volumeStats(candles)
  };
}
