import { indicators, supportResistance } from './indicators.js';

const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));

export function analyze(candles) {
  if(candles.length<40) return {status:'INSUFFICIENT DATA — WAIT',signal:'WAIT',nextMove:'SIDEWAYS',confidence:'LOW',bullish:0,bearish:0,reason:'At least 40 valid candles are required.'};
  const ind=indicators(candles), sr=supportResistance(candles,20), last=candles.at(-1), prev=candles.at(-2);
  if(!ind.ema9||!ind.ema21||ind.rsi==null||!ind.dmi||!ind.atr) return {status:'INSUFFICIENT DATA — WAIT',signal:'WAIT',nextMove:'SIDEWAYS',confidence:'LOW',bullish:0,bearish:0,reason:'Indicator data is incomplete.'};
  let bull=0,bear=0, reasons=[];
  // EMA: 20
  if(ind.ema9>ind.ema21){bull+=20;reasons.push('EMA 9 above EMA 21');}
  else if(ind.ema9<ind.ema21){bear+=20;reasons.push('EMA 9 below EMA 21');}
  // DMI/ADX: 20
  if(ind.dmi.adx>=20){
    if(ind.dmi.pdi>ind.dmi.mdi){bull+=20;reasons.push('DMI buyers stronger with ADX trend strength');}
    else if(ind.dmi.mdi>ind.dmi.pdi){bear+=20;reasons.push('DMI sellers stronger with ADX trend strength');}
  } else reasons.push('ADX below 20: trend strength is weak');
  // Volume: 20, but unavailable means no signal confirmation.
  const volumeAvailable=ind.volume.available;
  if(volumeAvailable){
    if(ind.volume.ratio>=1.5 && last.close>prev.close){bull+=20;reasons.push('Volume spike confirms upward candle');}
    else if(ind.volume.ratio>=1.5 && last.close<prev.close){bear+=20;reasons.push('Volume spike confirms downward candle');}
  } else reasons.push('Volume unavailable: confirmation not scored');
  // RSI: 15
  if(ind.rsi>=55 && ind.rsi<70){bull+=15;reasons.push('RSI supports bullish momentum');}
  else if(ind.rsi<=45 && ind.rsi>30){bear+=15;reasons.push('RSI supports bearish momentum');}
  // Price action: 15
  const range=Math.max(last.high-last.low,1e-9), body=Math.abs(last.close-last.open);
  if(last.close>last.open && body/range>=0.55){bull+=15;reasons.push('Strong bullish candle structure');}
  else if(last.close<last.open && body/range>=0.55){bear+=15;reasons.push('Strong bearish candle structure');}
  // S/R: 10
  const nearSupport=(last.close-sr.support)<=ind.atr*0.5;
  const nearResistance=(sr.resistance-last.close)<=ind.atr*0.5;
  if(last.close>sr.resistance){bull+=10;reasons.push('Resistance breakout');}
  else if(last.close<sr.support){bear+=10;reasons.push('Support breakdown');}
  else if(nearSupport && last.close>last.open){bull+=10;reasons.push('Bounce structure near support');}
  else if(nearResistance && last.close<last.open){bear+=10;reasons.push('Rejection structure near resistance');}

  const max=100;
  const gap=Math.abs(bull-bear);
  let nextMove=gap<15?'SIDEWAYS':bull>bear?'UP':'DOWN';
  let confidence=gap>=35?'HIGH':gap>=20?'MEDIUM':'LOW';
  // Require multiple confirmations; no volume => WAIT.
  let signal='WAIT';
  const confirmations=[ind.ema9>ind.ema21&&ind.dmi.pdi>ind.dmi.mdi&&ind.dmi.adx>=20,last.close>prev.close,volumeAvailable&&ind.volume.ratio>=1.2];
  const bearishConfirmations=[ind.ema9<ind.ema21&&ind.dmi.mdi>ind.dmi.pdi&&ind.dmi.adx>=20,last.close<prev.close,volumeAvailable&&ind.volume.ratio>=1.2];
  if(confirmations.every(Boolean)&&bull>=65&&confidence!=='LOW') signal='BUY';
  if(bearishConfirmations.every(Boolean)&&bear>=65&&confidence!=='LOW') signal='SELL';
  if(!volumeAvailable) signal='WAIT';
  return {status:'LIVE ANALYSIS',signal,nextMove,confidence,bullish:clamp(Math.round(bull),0,max),bearish:clamp(Math.round(bear),0,max),reasons,indicators:{ema9:ind.ema9,ema21:ind.ema21,rsi:ind.rsi,dmi:ind.dmi,atr:ind.atr,volume:ind.volume},support:sr.support,resistance:sr.resistance};
}

export function entryExit(candles, analysis) {
  const last=candles.at(-1), atr=analysis.indicators?.atr;
  if(!last||!atr) return null;
  const p=last.close, s=analysis.support, r=analysis.resistance;
  if(analysis.signal==='BUY'){
    const entryLow=Math.max(s||p-atr*0.4,p-atr*0.25), entryHigh=p+atr*0.1;
    const sl=Math.min(s||p-atr*1.2,p-atr*0.9);
    const t1=Math.max(r||p+atr*1.5,p+atr*1.5), t2=p+atr*2.5;
    return {side:'BUY',entry:[entryLow,entryHigh],stop:sl,target1:t1,target2:t2,rr:(t2-p)/Math.max(p-sl,1e-9)};
  }
  if(analysis.signal==='SELL'){
    const entryLow=p-atr*0.1, entryHigh=Math.min(r||p+atr*0.25,p+atr*0.25);
    const sl=Math.max(r||p+atr*1.2,p+atr*0.9);
    const t1=Math.min(s||p-atr*1.5,p-atr*1.5), t2=p-atr*2.5;
    return {side:'SELL',entry:[entryLow,entryHigh],stop:sl,target1:t1,target2:t2,rr:(p-t2)/Math.max(sl-p,1e-9)};
  }
  return null;
}
