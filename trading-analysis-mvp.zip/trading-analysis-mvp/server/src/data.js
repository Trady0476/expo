import WebSocket from 'ws';
import { indicators } from './indicators.js';

const apiKey=process.env.TWELVE_DATA_API_KEY;
const cfg={
 NIFTY:{symbol:process.env.NIFTY_SYMBOL||'NIFTY',exchange:process.env.NIFTY_EXCHANGE||'NSE',label:'NIFTY 50'},
 SENSEX:{symbol:process.env.SENSEX_SYMBOL||'SENSEX',exchange:process.env.SENSEX_EXCHANGE||'BSE',label:'SENSEX'},
 BTC:{symbol:process.env.BTC_SYMBOL||'BTC/USD',exchange:'',label:'BTC'}
};
const cache=new Map();
const clients=new Set();

function validCandle(x){
 return x && [x.open,x.high,x.low,x.close].every(v=>Number.isFinite(Number(v))) &&
   Number(x.high)>=Number(x.low) && Number(x.open)>0 && Number(x.close)>0;
}
function normalizeRows(rows){
 return (rows||[]).map(x=>({time:x.datetime||x.timestamp,open:+x.open,high:+x.high,low:+x.low,close:+x.close,volume:Number(x.volume)||0}))
   .filter(validCandle).reverse();
}
export function aggregate(candles, minutes){
 if(minutes===1) return candles;
 const buckets=new Map();
 for(const c of candles){
   const t=new Date(c.time).getTime();
   if(!Number.isFinite(t)) continue;
   const size=minutes*60*1000, key=Math.floor(t/size)*size;
   const a=buckets.get(key)||{time:new Date(key).toISOString(),open:c.open,high:c.high,low:c.low,close:c.close,volume:0};
   a.high=Math.max(a.high,c.high);a.low=Math.min(a.low,c.low);a.close=c.close;a.volume+=(Number(c.volume)||0);
   buckets.set(key,a);
 }
 return [...buckets.values()].sort((a,b)=>new Date(a.time)-new Date(b.time));
}
export async function fetchCandles(asset, interval='1min', outputsize=200){
 if(!apiKey) throw new Error('TWELVE_DATA_API_KEY is not configured');
 const c=cfg[asset]; if(!c) throw new Error('Unknown asset');
 const params=new URLSearchParams({symbol:c.symbol,interval,outputsize:String(outputsize),apikey:apiKey,timezone:'Asia/Kolkata'});
 if(c.exchange) params.set('exchange',c.exchange);
 const r=await fetch('https://api.twelvedata.com/time_series?'+params);
 if(!r.ok) throw new Error(`Provider HTTP ${r.status}`);
 const j=await r.json();
 if(j.status==='error'||!j.values) throw new Error(j.message||'Provider returned no candles');
 const candles=normalizeRows(j.values);
 if(candles.length<2) throw new Error('Not enough valid candles');
 return candles;
}
export async function fetchQuote(asset){
 if(!apiKey) throw new Error('TWELVE_DATA_API_KEY is not configured');
 const c=cfg[asset];
 const params=new URLSearchParams({symbol:c.symbol,apikey:apiKey,timezone:'Asia/Kolkata'});
 if(c.exchange) params.set('exchange',c.exchange);
 const r=await fetch('https://api.twelvedata.com/quote?'+params);
 if(!r.ok) throw new Error(`Provider HTTP ${r.status}`);
 const j=await r.json();
 if(j.status==='error'||j.close==null&&j.price==null) throw new Error(j.message||'No quote');
 return {asset,label:c.label,price:Number(j.price??j.close),change:Number(j.change??0),changePercent:Number(j.percent_change??0),isMarketOpen:Boolean(j.is_market_open),time:j.datetime||new Date().toISOString()};
}
export async function getMarket(asset, timeframe){
 const base=await fetchCandles(asset,'1min',240);
 const candles=aggregate(base,timeframe);
 const quote=await fetchQuote(asset);
 cache.set(asset,{quote,candles,updatedAt:new Date().toISOString()});
 return cache.get(asset);
}
export function getCache(asset){return cache.get(asset)||null;}

let providerWs=null;
export function startProviderStream(){
 if(!apiKey) return;
 try{
  providerWs=new WebSocket(`wss://ws.twelvedata.com/v1/quotes/price?apikey=${encodeURIComponent(apiKey)}`);
  providerWs.on('open',()=>{
    providerWs.send(JSON.stringify({action:'subscribe',params:{symbols:Object.values(cfg).map(x=>x.symbol).join(',')}}));
  });
  providerWs.on('message',raw=>{
    try{
      const m=JSON.parse(raw.toString());
      const symbol=m.symbol||m.data?.symbol;
      const price=Number(m.price??m.data?.price);
      if(!symbol||!Number.isFinite(price)) return;
      for(const [asset,c] of Object.entries(cfg)){
        if(c.symbol===symbol){
          const old=cache.get(asset)||{candles:[]};
          const quote={...(old.quote||{}),asset,label:c.label,price,change:old.quote?.change??0,changePercent:old.quote?.changePercent??0,isMarketOpen:true,time:new Date().toISOString()};
          cache.set(asset,{...old,quote,updatedAt:new Date().toISOString()});
          const payload=JSON.stringify({type:'tick',asset,quote});
          for(const ws of clients) if(ws.readyState===1) ws.send(payload);
        }
      }
    }catch{}
  });
  providerWs.on('close',()=>{providerWs=null;});
  providerWs.on('error',()=>{});
 }catch{}
}
export function addClient(ws){clients.add(ws);ws.on('close',()=>clients.delete(ws));}
export async function refreshAll(){
 for(const asset of Object.keys(cfg)){
  try{const data=await getMarket(asset,1);const payload=JSON.stringify({type:'market',asset,data});for(const ws of clients)if(ws.readyState===1)ws.send(payload);}
  catch{}
 }
}
export { cfg };
